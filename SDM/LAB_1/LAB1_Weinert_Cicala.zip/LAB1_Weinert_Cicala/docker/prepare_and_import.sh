#!/bin/bash
set -e

SKIP_IMPORT=${SKIP_IMPORT:-false}
SKIP_PARSING=${SKIP_PARSING:-false}
MAX_PAPER=${MAX_PAPER:-0}
MAX_EVENTS=${MAX_EVENTS:-0}


if [ $SKIP_IMPORT == "true" ]; then
    echo "Import already completed. Skipping to Neo4j startup...To start over delete the .data/import/ folder in the project. If this is unintended set SKIP_IMPORT to false in .env."
else
    if [ $SKIP_PARSING == "false" ]; then
        
        echo "Running parser..."
        python3 /app/PartA.2_Weinert_Cicala.py --xml_path /mydata/dblp.xml --csv_out /mydata/csv_out/ --max_paper $MAX_PAPER --max_events $MAX_EVENTS

        if compgen -G "/mydata/csv_out/*.csv" > /dev/null; then
            echo "Copying CSVs to import directory..."
            cp /mydata/csv_out/*.csv /import/
        else
            echo "No CSV files found in /mydata/csv_out. Exiting."
            exit 1
        fi
    else
        echo "Skipping parsing. If this is unintended set SKIP_PARSING to false in .env."
    fi
    # Run the Neo4j admin import
    echo "Importing into Neo4j..."
    /var/lib/neo4j/bin/neo4j-admin database import full neo4j \
      --nodes=/import/authors.csv \
      --nodes=/import/papers.csv \
      --nodes=/import/journals.csv \
      --nodes=/import/events.csv \
      --nodes=/import/keywords.csv \
      --nodes=/import/volumes.csv \
      --nodes=/import/editions.csv \
      --relationships=/import/wrote.csv \
      --relationships=/import/cited_by.csv \
      --relationships=/import/reviewed.csv \
      --relationships=/import/kw_indexes.csv \
      --relationships=/import/has_paper.csv \
      --relationships=/import/has_edition.csv \
      --relationships=/import/has_volume.csv \
      --verbose --overwrite-destination

    echo "Neo4j import complete."

fi

# Start Neo4j using the official entrypoint script
echo "Starting Neo4j..."
/startup/docker-entrypoint.sh neo4j
