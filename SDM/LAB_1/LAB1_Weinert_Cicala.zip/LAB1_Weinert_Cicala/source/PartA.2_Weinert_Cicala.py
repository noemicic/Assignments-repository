from enum import Enum
import lxml.etree as ET
import ftfy
import csv
from abc import ABC, abstractmethod
import numpy as np
import random
import argparse

DBLP_XML_PATH = "../data/dblp-2025-03-01.xml"
OUTPUT_PATH = "../data/csv/"
random.seed(42)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Parse DBLP XML and output CSVs for Neo4j import."
    )
    parser.add_argument(
        "--xml_path",
        type=str,
        default=DBLP_XML_PATH,
        help="Path to the input DBLP XML file.",
    )
    parser.add_argument(
        "--csv_out",
        type=str,
        default=OUTPUT_PATH,
        help="Output directory for generated CSV files.",
    )
    parser.add_argument(
        "--max_paper",
        type=int,
        default=0,
        help="Optional limit on the number of papers to parse (jorunal/event 1:1). 0 means no limit.",
    )
    parser.add_argument(
        "--max_events",
        type=int,
        default=0,
        help="Optional limit on the number of events to parse. 0 means no limit.",
    )
    return parser.parse_args()


class PubType(Enum):
    ARTICLE = "article"
    INPROCEEDINGS = "inproceedings"
    PROCEEDINGS = "proceedings"


def fix(text):
    """In case we want to add more fixing behaviour later - here:"""
    text = ftfy.fix_text(text)
    return text.replace('"', "'").replace("\n", " ").replace("\r", " ")


def skewed_sample(max_val=50, scale=0.3):
    # smaller scale = heavier bias to low numbers
    value = int(random.expovariate(scale))
    return min(max(value, 1), max_val)


class CSVWriter:
    """CSV Writer with buffered writing to improve performance."""

    buffer_size = 50000

    def __init__(self, filename, header, buffer_size=buffer_size):
        self.filename = filename
        self.buffer = (
            []
        )  # List to store buffered rows -> we save many I/O operations like this
        self.buffer_size = buffer_size
        with open(self.filename, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(header)

    def write_row(self, row):
        """Buffer rows and write to CSV in batches."""
        self.buffer.append(row)
        if len(self.buffer) >= self.buffer_size:
            self.flush()

    def rollback_last_write_row(self):
        """Remove the last row from the buffer."""
        self.buffer = self.buffer[:-1]

    def flush(self, final=False):
        """Write buffered data to CSV and clear buffer."""
        if self.buffer:
            rollback_window = 10
            with open(self.filename, "a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f, quoting=csv.QUOTE_ALL)
                writer.writerows(
                    self.buffer if final else self.buffer[:-rollback_window]
                )
            self.buffer = self.buffer[-rollback_window:]

    def close(self):
        """Ensure all buffered data is written before closing."""
        print(f"Closing {self.filename}...")
        self.flush(final=True)


class DblpXmlToCsvParser:

    class Entity(ABC):
        """Base class for all entities that can be saved to CSV."""

        output_path = "./csvs/"
        csv_writer: CSVWriter = (
            None  # Singleton writer: reusable across all instances of the class
        )

        def save(self):
            if self.csv_writer is not None:
                self.csv_writer.write_row(self.to_csv_row())
                if not DblpXmlToCsvParser.disable_rollback:
                    DblpXmlToCsvParser.rollback_list.append(self.__class__)
            else:
                raise ("Error: CSV writer not initialized.")

        @classmethod
        def finalize(cls):
            """Ensure all buffered data is written before closing the CSV."""
            if cls.csv_writer is not None:
                cls.csv_writer.close()

        @classmethod
        def rollback(cls):
            """Remove the last row from the buffer."""
            if cls.csv_writer is not None:
                cls.csv_writer.rollback_last_write_row()
            else:
                raise ("Error: CSV writer not initialized.")

        @abstractmethod
        def to_csv_row(self) -> list:
            pass

    class Paper(Entity):
        def __init__(self, paper_id, paper_key, title, doi, abstract):
            if self.__class__.csv_writer is None:
                self.__class__.csv_writer = CSVWriter(
                    self.__class__.output_path + "papers.csv",
                    [":ID", "key", "title", "doi", "abstract", ":LABEL"],
                    buffer_size=50000,
                )
            self.paper_id = paper_id
            self.paper_key = paper_key
            self.title = title
            self.doi = doi if doi is not None else "no doi"
            self.abstract = "no abstract available" if abstract is None else abstract
            self.label = "Paper"

        def to_csv_row(self) -> list:
            return [
                self.paper_id,
                self.paper_key,
                self.title,
                self.doi,
                self.abstract,
                self.label,
            ]

    class Author(Entity):
        def __init__(self, author_id, name):
            if self.__class__.csv_writer is None:
                self.__class__.csv_writer = CSVWriter(
                    self.__class__.output_path + "authors.csv",
                    [":ID", "name", ":LABEL"],
                )
            self.author_id = author_id
            self.name = name
            self.label = "Author"

        def to_csv_row(self) -> list:
            return [self.author_id, self.name, self.label]

    class Journal(Entity):
        def __init__(self, journal_id, name):
            if self.__class__.csv_writer is None:
                self.__class__.csv_writer = CSVWriter(
                    self.__class__.output_path + "journals.csv",
                    [":ID", "name", ":LABEL"],
                )
            self.journal_id = journal_id
            self.name = name
            self.label = "Journal"

        def to_csv_row(self) -> list:
            return [self.journal_id, self.name, self.label]

    class Event(Entity):
        def __init__(self, event_id, name):
            if self.__class__.csv_writer is None:
                self.__class__.csv_writer = CSVWriter(
                    self.__class__.output_path + "events.csv",
                    [
                        ":ID",
                        "name",
                        "event_type",
                        ":LABEL",
                    ],
                )
            self.event_id = event_id
            self.name = name
            self.event_type = "conference" if np.random.rand() < 0.5 else "workshop"
            self.label = "Event"

        def to_csv_row(self) -> list:
            return [self.event_id, self.name, self.event_type, self.label]

    class Keyword(Entity):
        def __init__(self, keyword_id, keyword):
            if self.__class__.csv_writer is None:
                self.__class__.csv_writer = CSVWriter(
                    self.__class__.output_path + "keywords.csv",
                    [":ID", "keyword", ":LABEL"],
                )
            self.keyword_id = keyword_id
            self.keyword = keyword
            self.label = "Keyword"

        def to_csv_row(self) -> list:
            return [self.keyword_id, self.keyword, self.label]

    class Volume(Entity):
        def __init__(self, volume_id, year, volume_number):
            if self.__class__.csv_writer is None:
                self.__class__.csv_writer = CSVWriter(
                    self.__class__.output_path + "volumes.csv",
                    [":ID", "year", "volume_number", ":LABEL"],
                )
            self.volume_id = volume_id
            self.year = year
            self.volume_number = volume_number
            self.label = "Volume"

        def to_csv_row(self) -> list:
            return [self.volume_id, self.year, self.volume_number, self.label]

    class Edition(Entity):
        def __init__(self, edition_id, title, year, city):
            if self.__class__.csv_writer is None:
                self.__class__.csv_writer = CSVWriter(
                    self.__class__.output_path + "editions.csv",
                    [":ID", "title", "year", "city", ":LABEL"],
                )
            self.edition_id = edition_id
            self.title = title
            self.year = year
            self.city = random.choice(
                ["Berlin", "New York", "Paris", "Tokyo", "London"]
            )
            self.label = "Edition"

        def to_csv_row(self) -> list:
            return [self.edition_id, self.title, self.year, self.city, self.label]

    class Relationship(Entity):
        def __init__(
            self,
            file_name,
            id_from,
            id_to,
            relationship_name,
            extra_field=None,
            extra_field_header=None,
            buffer_size=50000,
        ):
            if self.__class__.csv_writer is None:
                if extra_field is not None and extra_field_header is None:
                    extra_field_header = "extra_field"
                self.header = (
                    [":START_ID", ":END_ID", ":TYPE"]
                    if extra_field is None
                    else [":START_ID", ":END_ID", ":TYPE", extra_field_header]
                )
                self.__class__.csv_writer = CSVWriter(
                    self.__class__.output_path + file_name,
                    self.header,
                    buffer_size=buffer_size,
                )
            self.id_from = id_from
            self.id_to = id_to
            self.relationship_name = relationship_name
            self.extra_field = extra_field

        def to_csv_row(self) -> list:
            return (
                [self.id_from, self.id_to, self.relationship_name]
                if self.extra_field is None
                else [
                    self.id_from,
                    self.id_to,
                    self.relationship_name,
                    self.extra_field,
                ]
            )

    class CitedBy(Relationship):
        def __init__(self, citing_paper_id, cited_paper_id):
            super().__init__(
                "cited_by.csv",
                id_from=cited_paper_id,
                id_to=citing_paper_id,
                relationship_name="CITED_BY",
            )

    class Wrote(Relationship):
        def __init__(self, paper_id, author_id, corresponding: bool):
            super().__init__(
                "wrote.csv",
                id_from=author_id,
                id_to=paper_id,
                relationship_name="WROTE",
                extra_field="true" if corresponding else "false",
                extra_field_header="corresponding:boolean",
            )

    class Reviewed(Relationship):
        def __init__(self, paper_id, author_id):
            super().__init__(
                "reviewed.csv",
                id_from=author_id,
                id_to=paper_id,
                relationship_name="REVIEWED",
                buffer_size=500000,
            )

    class KwIndexes(Relationship):
        def __init__(self, paper_id, keyword_id):
            super().__init__(
                "kw_indexes.csv",
                id_from=keyword_id,
                id_to=paper_id,
                relationship_name="KW_INDEXES",
                buffer_size=500000,
            )

    class HasPaper(Relationship):
        def __init__(self, paper_id, volume_or_event_id):
            super().__init__(
                "has_paper.csv",
                id_from=volume_or_event_id,
                id_to=paper_id,
                relationship_name="HAS_PAPER",
            )

    class HasEdition(Relationship):
        def __init__(self, edition_id, event_id):
            super().__init__(
                "has_edition.csv",
                id_from=event_id,
                id_to=edition_id,
                relationship_name="HAS_EDITION",  # or "HAS_EDITION" but the direction is the opposite
            )

    class HasVolume(Relationship):
        def __init__(self, volume_id, journal_id):
            super().__init__(
                "has_volume.csv",
                id_from=journal_id,
                id_to=volume_id,
                relationship_name="HAS_VOLUME",  # or "HAS_VOLUME" but the direction is the opposite
            )

    class_list = [
        Paper,
        Author,
        Journal,
        Event,
        Keyword,
        Volume,
        Edition,
        CitedBy,
        Wrote,
        Reviewed,
        KwIndexes,
        HasPaper,
        HasEdition,
        HasVolume,
    ]
    # store the last processed elements to rollback in case of error,
    rollback_list = []
    disable_rollback = False  # set to True to disable rollback functionality

    def __init__(
        self,
        xml_path: str = "dblp.xml",
        csv_folder_path: str = OUTPUT_PATH,
        max_dict: dict = {
            PubType.ARTICLE: 0,  # <=0 is ALL
            PubType.INPROCEEDINGS: 0,
            PubType.PROCEEDINGS: 0,
        },
    ):
        self.__class__.Entity.output_path = csv_folder_path

        self.xml_path = xml_path

        self.counters = {pub.value: 0 for pub in PubType}
        self.last_printed = -1
        self.max_elements = {
            pub.value: max_dict[pub] if pub in max_dict else 0 for pub in PubType
        }
        self.max_reached = set()

        self.maps = {
            "paper": {},
            "author": {},
            "journal": {},
            "volume": {},
            "event": {},
            "edition": {},
            "keyword": {},
            "edition_to_event": {},  # -> to later assign biased keyword generation, clumsy fix, but were not refactoring everything at thisn point for thhe recommender :D
            "paper_to_venue": {},  # -> to later assign biased keyword generation
        }  # all mapping a name to a generated id -> each gets added only once but we can ressolve relationships by getting the id
        self.db_venue_ids = set()
        self.next_id = 0  # next id to assign to a new entity
        self.finalized = set()  # store the already finalized classes
        self.rollback_map = {
            x: [] for x in self.maps.keys()
        }  # store the last added key per map to rollback in case of error

    def parse_dblp_xml(self) -> None:
        """main function to orchestrate DBLP XML file parsing.

        Call this one after initializing the parser."""

        for pub_type in [
            PubType.PROCEEDINGS.value,
            PubType.INPROCEEDINGS.value,
            PubType.ARTICLE.value,
        ]:
            context = ET.iterparse(
                self.xml_path,
                events=("end",),
                tag=pub_type,
                load_dtd=True,
                resolve_entities=True,
                recover=True,
                huge_tree=True,
            )
            _, root = next(
                context
            )  # hre we getting the <dlbp/> root element, from that we can clear already processed elements
            self.main_iteration(context, root, pub_type)
            del context, root
            self.cleanup(pub_type)

        venue_ids = list(self.maps["event"].values()) + list(
            self.maps["journal"].values()
        )
        self.db_venue_ids = set(
            random.sample(venue_ids, int(0.05 * len(venue_ids)))  # 5% DB-heavy venues
        )
        self.fake()
        to_finalize = [
            x for x in DblpXmlToCsvParser.class_list if x not in self.finalized
        ]
        self.finalize(to_finalize)

    def cleanup(self, pub_type):
        if pub_type == PubType.PROCEEDINGS.value:
            to_finalize = [
                DblpXmlToCsvParser.Event,
                DblpXmlToCsvParser.Edition,
                DblpXmlToCsvParser.HasEdition,
            ]
        elif pub_type == PubType.INPROCEEDINGS.value:
            to_finalize = []
            del (self.maps["edition"],)  # conferences done, lets free some memory
        elif pub_type == PubType.ARTICLE.value:
            to_finalize = [
                DblpXmlToCsvParser.Journal,
                DblpXmlToCsvParser.Volume,
                DblpXmlToCsvParser.HasVolume,
                DblpXmlToCsvParser.HasPaper,
                DblpXmlToCsvParser.Paper,
                DblpXmlToCsvParser.Author,
            ]
            del self.maps["volume"]
        self.finalize(to_finalize)
        del self.counters[pub_type], self.max_elements[pub_type]

    def main_iteration(self, context, root, pub_type) -> None:
        for _, elem in context:
            if self.max_elements[pub_type] > 0:
                if self.counters[pub_type] >= self.max_elements[pub_type]:
                    print(
                        f"Max limit reached for {pub_type}. Skipping further elements."
                    )
                    return
            if (
                self.counters[pub_type] % 1000 == 0
                and self.last_printed != self.counters[pub_type]
            ):
                print(f"Processed {self.counters[pub_type]} {pub_type} elements.")
                self.last_printed = self.counters[pub_type]

            try:
                if self.parse_element(elem, pub_type):
                    self.counters[pub_type] += 1
            except Exception as e:
                print(f"Error processing {pub_type}: {e}")
                self.rollback()
            finally:
                self.reset_rollback()
                while elem.getprevious() is not None:
                    prev = elem.getprevious()
                    prev.clear()
                    elem.getparent().remove(prev)
                elem.clear()
                root.clear()  # being extremly conservative here lol, memory is the biggest concern
                del elem

    def element_health_check(self, element: ET.Element, pub_type: PubType) -> bool:
        """Check if an element is complete and valid."""
        key = element.get("key")
        if key is None or (
            "publtype" in element.attrib and element.get("publtype") == "informal"
        ):  # catching corrupted records, metadata articles (informal), papers first published in conferences
            return False
        if pub_type == PubType.ARTICLE.value:
            if not key.startswith("journals/"):  # or....
                return False
            required_fields = ["author", "journal", "title", "year", "volume"]
        elif pub_type == PubType.INPROCEEDINGS.value:
            crossref = element.find("crossref")
            if (
                not key.startswith("conf/")
                or crossref is None
                or crossref.text not in self.maps["edition"].keys()
            ):
                return False
            required_fields = ["author", "title", "year", "crossref"]
        elif pub_type == PubType.PROCEEDINGS.value:
            if not key.startswith("conf/"):
                return False
            required_fields = ["title", "year"]
        else:
            raise ValueError(
                f"Unsupported publication type: {pub_type} in health check."
            )
        for required_field in required_fields:
            if required_field in element.attrib:
                if element.attrib[required_field].strip():
                    continue
            child = element.find(required_field)
            if child is None:
                return False
            text = "".join(child.itertext()).strip()
            if not text:
                return False
        # seems pretty healthy *_*
        return True

    def get_data_from_element(self, element: ET.Element) -> dict:
        data = {}
        data["key"] = element.get(
            "key"
        )  # journals/rlc/ChangFMD24 -> ChangFMD24 (actual identifier)
        for child in element:
            value = "".join(child.itertext()).strip()
            if value is None or value == "":
                continue
            else:
                value = fix(value)

            if child.tag == "author":
                if "authors" not in data or data["authors"] is None:
                    data["authors"] = [value]
                else:
                    data["authors"].append(value)
            else:
                data[child.tag] = value
        return data

    def parse_element(self, element: ET.Element, pub_type: PubType) -> bool:
        """Parse an element based on its publication type."""
        if not self.element_health_check(element, pub_type):
            return False
        try:
            data = self.get_data_from_element(element)
        except Exception as e:
            print(f"Error while tring to extract data from healthy element: {e}")
            return False
        if pub_type in [PubType.ARTICLE.value, PubType.INPROCEEDINGS.value]:
            return self.paper_to_csv(
                data, pub_type
            )  # either conference or journal paper
        elif pub_type == PubType.PROCEEDINGS.value:
            return self.conf_to_csv(data)
        else:
            return False

    def paper_to_csv(self, data: dict, pub_type: PubType) -> bool:
        """Creates Paper and Author rows and relationship for conference AND journal paper.
        Calls the respective handler for conference or journal."""
        # paper entity - samesame for both inproceeding and article
        paper_key = data[
            "key"
        ]  # e.g. journals/rlc/ChangFMD24 -> cutting off journals/rlc/ would introduce ambiguity
        new_entry, paper_id = self.get_or_create_next_id(paper_key, "paper")
        if not new_entry:
            return False  # already existent, no need to add again
        paper = DblpXmlToCsvParser.Paper(
            paper_id=paper_id,
            paper_key=paper_key,  # e.g. journals/rlc/ChangFMD24 -> ChangFMD24 (actual identifier)
            title=data["title"],
            doi=data.get("ee", None),
            abstract=data.get("abstract", None),
        )
        paper.save()

        # author entity + wrote relationship - samesame for both inproceeding and article
        corresponding = True  # we randomly assign the first author as being the corresponding author (best guess approach)
        for author in data["authors"]:
            new_entry, author_id = self.get_or_create_next_id(author, "author")
            if new_entry:
                author = DblpXmlToCsvParser.Author(
                    author_id, author
                )  # for instance Max Muster 0001 and Max Muster 0002....(thats how dblp handles it)
                author.save()
            DblpXmlToCsvParser.Wrote(paper_id, author_id, corresponding).save()
            corresponding = False  # never becomes True again -> first is corresponding

        # if journal paper -> save to csv and create relationships
        # if conference paper -> create relationship if conference already created OR save crossref until matching preceeding element
        if pub_type == PubType.ARTICLE.value:
            new_entry, journal_id = self.get_or_create_next_id(
                data["journal"], "journal"
            )
            if new_entry:
                DblpXmlToCsvParser.Journal(journal_id, data["journal"]).save()

            new_entry, volume_id = self.get_or_create_next_id(
                data["journal"] + data["volume"] + data["year"], "volume"
            )  # "number_volume" instead of "volume"
            if new_entry:
                DblpXmlToCsvParser.Volume(
                    volume_id, data["year"], data["volume"]
                ).save()  # "number_volume" instead of "volume"
                DblpXmlToCsvParser.HasVolume(volume_id, journal_id).save()
            self.maps["paper_to_venue"][paper_id] = journal_id
            DblpXmlToCsvParser.HasPaper(paper_id, volume_id).save()
            return True

        elif pub_type == PubType.INPROCEEDINGS.value:
            edition_id = self.maps["edition"][data["crossref"]]
            DblpXmlToCsvParser.HasPaper(paper_id, edition_id).save()
            self.maps["paper_to_venue"][paper_id] = self.maps["edition_to_event"][
                edition_id
            ]
            return True

        self.rollback()
        return False

    def conf_to_csv(self, data: dict) -> bool:
        """Creates Event, Edition, and relationships for a conference paper."""
        # full key is edition identifier! e.g. conf/cscl/2021-2 split("/")[1] is the event identifier
        event_key = data["key"].split("/")[1]
        edition_key = data["key"]

        new_entry, edition_id = self.get_or_create_next_id(edition_key, "edition")
        if new_entry:
            DblpXmlToCsvParser.Edition(
                edition_id, data["title"], data["year"], data.get("city", "")
            ).save()

        new_entry, event_id = self.get_or_create_next_id(event_key, "event")
        if new_entry:
            DblpXmlToCsvParser.Event(
                event_id,
                event_key,
            ).save()

        DblpXmlToCsvParser.HasEdition(edition_id, event_id).save()
        self.maps["edition_to_event"][
            edition_id
        ] = event_id  # to later assign biased keyword generation
        return new_entry  # dont count up if event was already existent.

    def rollback(self):
        """Rollback the last processed elements."""
        for cls in DblpXmlToCsvParser.rollback_list:
            cls.rollback()
        for entity, last_added_list in self.rollback_map.items():
            while last_added_list != []:
                key = last_added_list.pop()
                del self.maps[entity][key]
        self.reset_rollback()

    def get_or_create_next_id(self, name, entity):
        """Assigns a unique ID to an author or reuses an existing one."""
        new_entry = False

        if name not in self.maps[entity]:
            self.maps[entity][name] = self.next_id
            self.rollback_map[entity].append(name)
            self.next_id += 1
            new_entry = True

        return new_entry, self.maps[entity][name]

    def reset_rollback(self):
        DblpXmlToCsvParser.rollback_list.clear()
        self.rollback_map = {k: [] for k in self.rollback_map.keys()}

    def fake(self):
        """Fakes citations, reviews and keyords for all papers."""
        print("Faking citations, reviews and keywords...")
        DblpXmlToCsvParser.disable_rollback = True  # disable rollback for this part
        for keyword in KEYWORDS:
            new_entry, keyword_id = self.get_or_create_next_id(keyword, "keyword")
            if new_entry:
                DblpXmlToCsvParser.Keyword(keyword_id, keyword).save()
        print("Keywords done.")

        count = 0
        all_keywords = list(self.maps["keyword"].values())
        db_keywords = [
            kid for kw, kid in self.maps["keyword"].items() if kw in DB_COMMUNITY
        ]
        db_bias_prob = (
            0.95  # 95% of the time we use a DB keyword when facing a db community paper
        )

        all_paper_ids = list(self.maps["paper"].values())
        all_author_ids = list(self.maps["author"].values())
        db_papers = [
            paper_id
            for paper_id, venue in self.maps["paper_to_venue"].items()
            if venue in self.db_venue_ids
        ]
        db_papers_len = len(db_papers)
        db_papers_weights = [
            db_papers_len - i for i in range(db_papers_len)
        ]  # makes sure some are chosen more often for citations -> guru etc
        for paper_id in self.maps["paper"].values():
            db_venue = False
            if self.maps["paper_to_venue"][paper_id] in self.db_venue_ids:
                db_venue = True

            if db_venue and random.random() < db_bias_prob:
                keyword_ids = random.sample(db_keywords, random.randint(2, 3))
                keyword_ids += random.sample(all_keywords, random.randint(0, 2))
            else:
                keyword_ids = random.sample(all_keywords, random.randint(1, 5))

            for kw_id in keyword_ids:
                DblpXmlToCsvParser.KwIndexes(paper_id, kw_id).save()

            cites_ids = set(random.sample(all_paper_ids, skewed_sample()))
            if db_venue:
                cites_ids.update(
                    set(
                        random.choices(
                            db_papers,
                            weights=db_papers_weights,
                            k=skewed_sample(scale=0.4),
                        )
                    )
                )
            for cites_id in cites_ids:
                if paper_id == cites_id:
                    continue
                DblpXmlToCsvParser.CitedBy(cites_id, paper_id).save()

            reviewers = random.sample(all_author_ids, 3)
            # actually we dont check if someone is reviewing his own paper, but at this sample size it should be fine, especially for that demo
            # the bigger concern is memory and cpu at this scale so we just assume that the reviewers are not the authors of the paper (probably right in 99.999%+ of the cases)
            for reviewer in reviewers:
                DblpXmlToCsvParser.Reviewed(paper_id, reviewer).save()
            count += 1
            if count % 10000 == 0:
                print(f"Processed {count} papers for citations and reviews.")
        print("Citations and reviews done.")

    def finalize(self, classes=None):
        """Ensure all buffered data is written before closing the CSV."""
        if classes is None:
            classes = DblpXmlToCsvParser.class_list
        for cls in classes:
            cls.finalize()
            self.finalized.add(cls)

    def explore_pub_type(self, pub_type: PubType, sample_size: int = 1000):
        """Explore the structure of a publication type element."""
        counter_attrib = {}
        counter_child = {}

        context = ET.iterparse(
            self.xml_path,
            events=("end",),
            tag=pub_type.value,
            huge_tree=True,
        )
        _, root = next(context)
        for _, elem in context:

            if sample_size <= 0:
                break
            for attrib in elem.attrib:
                print(attrib)
                print(elem.attrib[attrib])
                counter_attrib[attrib] = counter_attrib.get(attrib, 0) + 1

            for child in elem:
                print(child.tag)
                print(child.text)
                counter_child[child.tag] = counter_child.get(child.tag, 0) + 1

            root.clear()
            sample_size -= 1

        print(counter_attrib)
        print(counter_child)


KEYWORDS = [
    "Graph Processing",
    "Data Quality",
    "Machine Learning",
    "Deep Learning",
    "Knowledge Graphs",
    "Big Data",
    "Natural Language Processing",
    "AI Ethics",
    "Cybersecurity",
    "Blockchain",
    "Computer Vision",
    "Quantum Computing",
    "Recommender Systems",
    "Federated Learning",
    "Ontology Engineering",
    "Data Mining",
    "Anomaly Detection",
    "Cloud Computing",
    "Edge Computing",
    "Neural Networks",
    "Algorithm Optimization",
    "Software Engineering",
    "Information Retrieval",
    "Human-Computer Interaction",
    "Explainable AI",
    "Bayesian Networks",
    "Data Privacy",
    "Internet of Things (IoT)",
    "Reinforcement Learning",
    "Computational Linguistics",
    "Bioinformatics",
    "Time Series Analysis",
    "Graph Neural Networks",
    "Speech Recognition",
    "Swarm Intelligence",
    "Evolutionary Algorithms",
    "Autonomous Systems",
    "Cryptography",
    "Robotic Process Automation",
    "Parallel Computing",
    "Embedded Systems",
    "Formal Verification",
    "Wireless Sensor Networks",
    "Data Fusion",
    "Causal Inference",
    "Smart Contracts",
    "Self-Supervised Learning",
    "Virtual Reality",
    "Augmented Reality",
    "Multimodal Learning",
    "Data Management",
    "Indexing",
    "Data Modeling",
    "Big Data",
    "Data Processing",
    "Data Storage",
    "Data Querying",
]

DB_COMMUNITY = [
    "Data Management",
    "Indexing",
    "Data Modeling",
    "Big Data",
    "Data Processing",
    "Data Storage",
    "Data Querying",
]


if __name__ == "__main__":
    args = parse_args()
    max_paper = args.max_paper
    max_events = args.max_events
    if max_paper > 0:
        actual_max_paper = int(args.max_paper / 2)
    else:
        actual_max_paper = 0

    parser = DblpXmlToCsvParser(
        xml_path=args.xml_path,
        csv_folder_path=args.csv_out,
        max_dict={
            PubType.ARTICLE: actual_max_paper,
            PubType.INPROCEEDINGS: actual_max_paper,
            PubType.PROCEEDINGS: max_events,
        },
    )
    parser.parse_dblp_xml()
