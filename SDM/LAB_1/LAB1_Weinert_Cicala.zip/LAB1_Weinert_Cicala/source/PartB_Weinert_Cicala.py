from neo4j import GraphDatabase
import pandas as pd
import os, logging
from dotenv import load_dotenv
from tabulate import tabulate
from result_writer import ResultWriter

load_dotenv(dotenv_path="../.env")

LIMIT_ENTITIES = int(os.getenv("LIMIT_ENTITIES", 10))
NEO4J_URI = os.getenv("NEO4J_URI")
NEO4J_USER = os.getenv("NEO4J_USER")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")
RESULT_FOLDER = "../results/"
IMPACT_FACTOR_YEAR = os.getenv("IMPACT_FACTOR_YEAR")

result_writer = ResultWriter(RESULT_FOLDER)


class Neo4jQueryRunner:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        self.driver.close()

    def run_query(self, query, description, flatten=False):
        with self.driver.session() as session:
            result = session.run(query)
            records = [record.data() for record in result]

            if not records:
                print("No results found.")
                return

            if flatten:
                flat_rows = []
                for row in records:
                    event = row.get("event")
                    for paper in row.get("topPapers", []):
                        flat_rows.append(
                            {
                                "Event": event,
                                "Paper": paper["paper"],
                                "Citations": paper["citations"],
                            }
                        )
                df = pd.DataFrame(flat_rows)
            else:
                df = pd.DataFrame(records)

            result_writer.save_results(df, description)


if __name__ == "__main__":
    runner = Neo4jQueryRunner(NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD)

    queries = [
        {
            "desc": "B.1 Top 3 most cited papers per event",
            "query": f"""
                MATCH (e:Event)
                LIMIT {LIMIT_ENTITIES}
                MATCH (e)-[:HAS_EDITION]->()-[:HAS_PAPER]->(p:Paper)
                MATCH (p)-[r:CITED_BY]->()
                WITH e, p.title AS title, COUNT(r) AS citationCount
                ORDER BY e, citationCount DESC
                WITH e.name AS event, COLLECT({{paper: title, citations: citationCount}})[0..3] AS topPapers
                RETURN event, topPapers
            """,
            "flatten": True,
        },
        {
            "desc": "B.2 Authors who published in at least 4 editions of the same event",
            "query": f"""
                MATCH (e:Event)-[:HAS_EDITION]->(ed:Edition)
                WITH e, COLLECT(ed) AS editions
                WHERE SIZE(editions) >= 4
                WITH e, editions
                LIMIT {LIMIT_ENTITIES}
                UNWIND editions AS ed
                MATCH (ed)-[:HAS_PAPER]->(p:Paper)<-[:WROTE]-(a:Author)
                WITH e, a.name AS author, COUNT(DISTINCT ed) AS editionsCount
                WHERE editionsCount >= 4
                ORDER BY e, editionsCount DESC
                RETURN e.name AS event, author, editionsCount
            """,
            "flatten": False,
        },
        {
            "desc": "B.3 Impact factor of journals",
            "query": f"""
                WITH {IMPACT_FACTOR_YEAR} AS currentYear
                MATCH (journal:Journal)-[:HAS_VOLUME]->(vol:Volume)
                WHERE toInteger(vol.year) IN [currentYear - 1, currentYear - 2]
                WITH journal, COLLECT(vol) AS volumes
                UNWIND volumes AS vol
                MATCH (vol)-[:HAS_PAPER]->(p:Paper)
                WITH journal, COLLECT(p) AS papers
                WITH journal, papers, SIZE(papers) AS numRecentPapers
                WHERE numRecentPapers > 100 // makes it more interesting
                LIMIT {LIMIT_ENTITIES}
                UNWIND papers AS p
                MATCH (p)-[:CITED_BY]->()
                WITH journal, numRecentPapers, COUNT(*) AS citationsInCurrentYear
                RETURN journal.name AS journal,
                       ROUND(1.0 * citationsInCurrentYear / numRecentPapers, 2) AS impactFactor,
                       citationsInCurrentYear,
                       numRecentPapers
                ORDER BY impactFactor DESC
            """,
            "flatten": False,
        },
        {
            "desc": "B.4 H-index of authors",
            "query": f"""                
                MATCH (a:Author)
                LIMIT {LIMIT_ENTITIES}
                MATCH (a)-[:WROTE]->(p:Paper)
                MATCH (p)-[r:CITED_BY]->()
                WITH a, p, COUNT(r) AS citationCount
                WITH a, COLLECT(citationCount) AS counts
                WITH a, apoc.coll.sort(counts) AS sortedCounts
                UNWIND RANGE(0, SIZE(sortedCounts)-1) AS i
                WITH a, i, sortedCounts[SIZE(sortedCounts)-1 - i] AS c
                WHERE c >= i + 1
                WITH a, MAX(i + 1) AS hIndex
                RETURN a.name AS author, hIndex
                ORDER BY hIndex DESC
            """,
            "flatten": False,
        },
    ]
    for q in queries:
        runner.run_query(q["query"], q["desc"], q.get("flatten", False))
    runner.close()
