import os
import logging
import pandas as pd
from tabulate import tabulate

RESULT_FOLDER = "../results/"

class ResultWriter:
    def __init__(self, result_folder: str = RESULT_FOLDER):
        self.result_folder = result_folder
        os.makedirs(RESULT_FOLDER, exist_ok=True)

        logging.basicConfig(
            filename=self.result_folder + "/query_log.txt",
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s",
        )

        if not os.path.exists(result_folder):
            os.makedirs(result_folder)

    def save_results(self, df: pd.DataFrame, description: str):
        safe_desc = description.lower().replace(" ", "_")
        csv_path = self.result_folder + f"{safe_desc}.csv"
        df.to_csv(csv_path, index=False)
        html_path = self.result_folder + f"{safe_desc}.html"
        df.to_html(html_path, index=False)
        logging.info(f"=== {description} ===\n{df.to_string(index=False)}\n")
        print(f"\n=== {description} ===\n")
        print(tabulate(df, headers="keys", tablefmt="fancy_grid", showindex=False))
