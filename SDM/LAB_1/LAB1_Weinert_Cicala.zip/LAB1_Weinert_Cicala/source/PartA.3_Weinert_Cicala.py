from neo4j import GraphDatabase
import os
from dotenv import load_dotenv

load_dotenv(dotenv_path="../.env")
NEO4J_URI = os.getenv("NEO4J_URI")
NEO4J_USER = os.getenv("NEO4J_USER")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")

cypher_evolve_reviews = """
CALL apoc.periodic.iterate(
  "MATCH (a:Author)-[r:REVIEWED]->(p:Paper) RETURN r, p.title AS title, a.name AS reviewer",
  "SET r.content = 'Review of ' + title + ' by ' + reviewer,
        r.suggested_decision = CASE WHEN rand() < 0.5 THEN 'accept' ELSE 'reject' END",
  {batchSize: 10000, parallel: false}
)
"""

cypher_create_affiliations = """
UNWIND [
  {name: 'UPC', type: 'university'},
  {name: 'UAB', type: 'university'},
  {name: 'MIT', type: 'university'},
  {name: 'Stanford', type: 'university'},
  {name: 'Oxford', type: 'university'},
  {name: 'Google', type: 'company'},
  {name: 'Microsoft', type: 'company'},
  {name: 'Amazon', type: 'company'},
  {name: 'IBM', type: 'company'},
  {name: 'ETH Zurich', type: 'university'}
] AS aff
MERGE (:Affiliation {name: aff.name, type: aff.type});
"""

cypher_assign_affiliations = """
CALL apoc.periodic.iterate(
  "MATCH (a:Author) RETURN a",
  "
  MATCH (aff:Affiliation)
  WITH a, collect(aff) AS affs
  WITH a, apoc.coll.randomItem(affs) AS randomAff
  MERGE (a)-[:AFFILIATED_WITH]->(randomAff)
  ",
  {batchSize: 10000, parallel: false}
)
"""


def run_queries():
    driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))
    with driver.session() as session:
        print("Evolving REVIEWED relationships...")
        session.run(cypher_evolve_reviews)
        print("REVIEWED relationships updated.")

        print("Creating affiliations...")
        session.run(cypher_create_affiliations)
        print("Affiliation nodes created.")

        print("Linking authors to affiliations...")
        session.run(cypher_assign_affiliations)
        print("Authors linked to affiliations.")

    driver.close()


if __name__ == "__main__":
    run_queries()
