from neo4j import GraphDatabase
import pandas as pd
import os, logging
from dotenv import load_dotenv
from result_writer import ResultWriter

load_dotenv(dotenv_path="../.env")

NEO4J_URI = os.getenv("NEO4J_URI")
NEO4J_USER = os.getenv("NEO4J_USER")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")
RESULT_FOLDER = "../results/"

result_writer = ResultWriter(RESULT_FOLDER)


class Neo4jQueryRunner:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        self.driver.close()

    def run_query(self, query, description):
        with self.driver.session() as session:
            result = session.run(query)
            records = [record.data() for record in result]

            if not records:
                print("No results found.")
                return

            df = pd.DataFrame(records)
            result_writer.save_results(df, description)


DB_COMMUNITY = [
    "Data Management",
    "Indexing",
    "Data Modeling",
    "Big Data",
    "Data Processing",
    "Data Storage",
    "Data Querying",
]
keywords_cypher_array = "[" + ", ".join(f"'{kw}'" for kw in DB_COMMUNITY) + "]"

if __name__ == "__main__":
    runner = Neo4jQueryRunner(NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD)

    queries = [
        {
            "desc": "C.1 - Define 'database' community and link keywords",
            "query": f"""
                MERGE (c:Community {{name: 'database'}})
                WITH c
                UNWIND {keywords_cypher_array} AS kw
                MATCH (k:Keyword {{keyword: kw}})
                MERGE (c)-[:DEFINED_BY]->(k)
                RETURN c.name AS community, COLLECT(k.keyword) AS keywords
            """,
        },
        {
            "desc": "C.2 - Identify venues relevant to 'database' community",
            "query": """
                MATCH (c:Community {name: 'database'})-[:DEFINED_BY]->()-[:KW_INDEXES]->(p:Paper)<-[:HAS_PAPER]-()<-[:HAS_EDITION|HAS_VOLUME]-(venue)
                WITH c, venue, COUNT(DISTINCT p) AS db_papers
                MATCH (venue)-[:HAS_EDITION|HAS_VOLUME]->()-[:HAS_PAPER]->(p2:Paper)
                WITH c, venue, db_papers, COUNT(p2) AS total_papers
                WHERE total_papers > 100 AND db_papers * 1.0 / total_papers >= 0.9
                MERGE (c)-[:RELEVANT_VENUE]->(venue)
                RETURN 'Linked ' + COUNT(venue) + ' venues to community' AS info
            """,
        },
        {
            "desc": "C.3 - Find top 100 database papers by community citations",
            "query": """
                MATCH (c:Community {name: "database"})-[:RELEVANT_VENUE]->(v)-[:HAS_EDITION|HAS_VOLUME]->()-[:HAS_PAPER]->(p:Paper)
                MATCH (p)-[:CITED_BY]->(citing:Paper)<-[:HAS_PAPER]-()<-[:HAS_VOLUME|HAS_EDITION]-()<-[:RELEVANT_VENUE]-(c)
                WITH p, COUNT(DISTINCT citing) AS citationCount
                ORDER BY citationCount DESC
                LIMIT 100
                SET p.top_100_db = true
                RETURN 'Marked ' + COUNT(p) + ' papers as top DB papers' AS info
            """,
        },
        {
            "desc": "C.4 - Tag reviewers and gurus for 'database' community",
            "query": """
                MATCH (p:Paper {top_100_db: true})<-[:WROTE]-(a:Author)
                WITH a, COUNT(DISTINCT p) AS topPapers
                MERGE (c:Community {name: 'database'})-[:RECOMMENDED_REVIEWER]->(a)
                WITH a, topPapers
                WHERE topPapers >= 2
                MERGE (c)-[:GURU]->(a)
                RETURN a.name AS author, topPapers, 
                    CASE WHEN topPapers >= 2 THEN 'GURU' ELSE 'Reviewer' END AS status
            """,
        },
    ]
    counter = 0
    for q in queries:
        runner.run_query(q["query"], q["desc"])
    runner.close()
