from neo4j import GraphDatabase
import os
from dotenv import load_dotenv

load_dotenv(dotenv_path="../.env")

NEO4J_URI = os.getenv("NEO4J_URI")
NEO4J_USER = os.getenv("NEO4J_USER")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")


class LouvainRunner:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        self.driver.close()

    def run(self):
        with self.driver.session() as session:
            print("Dropping previous projection if exists...")
            session.run("CALL gds.graph.drop('authorGraph', false) YIELD graphName")

            print("Projecting co-author graph...")
            session.run(
                """
                CALL gds.graph.project.cypher(
                  'authorGraph',
                  'MATCH (a:Author) RETURN id(a) AS id',
                  '
                    MATCH (a1:Author)-[:WROTE]->(p:Paper)<-[:WROTE]-(a2:Author)
                    WHERE id(a1) < id(a2)
                    RETURN id(a1) AS source, id(a2) AS target
                  '
                )
            """
            )

            print("Running Louvain community detection...")
            result = session.run(
                """
                CALL gds.louvain.write('authorGraph', {
                  writeProperty: 'community'
                })
                YIELD communityCount, modularity
            """
            )
            for record in result:
                print("Louvain result:", record)

            print("Top 10 authors and their communities")
            result = session.run(
                """
                MATCH (a:Author)
                RETURN a.name AS author, a.community AS community
                ORDER BY community
                LIMIT 10
            """
            )
            for record in result:
                print(record)

            print("Cleaning up...")
            session.run("CALL gds.graph.drop('authorGraph') YIELD graphName")


class PageRankRunner:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        self.driver.close()

    def run(self):
        with self.driver.session() as session:
            print("Dropping previous projection if exists...")
            session.run("CALL gds.graph.drop('citationGraph', false) YIELD graphName")

            print("Projecting citation graph...")
            session.run(
                """
                CALL gds.graph.project(
                  'citationGraph',
                  'Paper',
                  'CITED_BY'
                )
            """
            )

            print("Running PageRank...")
            result = session.run(
                """
                CALL gds.pageRank.write('citationGraph', {
                  maxIterations: 20,
                  dampingFactor: 0.85,
                  writeProperty: 'pagerank'
                })
                YIELD nodePropertiesWritten, ranIterations
            """
            )
            for record in result:
                print("PageRank complete:", record)

            print("Top papers by PageRank:")
            result = session.run(
                """
                MATCH (p:Paper)
                RETURN p.title AS title, p.pagerank AS score
                ORDER BY score DESC
                LIMIT 10
            """
            )
            for record in result:
                print(f"{record['score']:.4f} - {record['title']}")

            print("Cleaning up...")
            session.run("CALL gds.graph.drop('citationGraph') YIELD graphName")


if __name__ == "__main__":
    pagerank = PageRankRunner(NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD)
    pagerank.run()
    pagerank.close()

    louvain = LouvainRunner(NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD)
    louvain.run()
    louvain.close()
