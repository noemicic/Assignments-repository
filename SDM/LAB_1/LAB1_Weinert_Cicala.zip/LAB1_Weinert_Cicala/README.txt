This repository contains all the necessary files and resources for reproducing the work. Below is a description of the folder and file structure:

📁 data/
	📁 import/
	Directory for input datasets: here you have to paste the parsed CSVs provided by the link: https://1drv.ms/u/s!AsezANZLUWP9kPgZz7lbh1akCku2wg?e=dRQLPy (more infos in the User Guide in DOC_Weinert_Cicala.pdf)
📁 docker/
Contains Docker-related configuration files, scripts, and setup to run the environment in a containerized way.

📁 results/
Stores output files generated during the execution, including logs or CSVs.

📁 source/
Contains the source code (Python scripts, Cypher queries, utilities, etc.) used to build and analyze the graph.
Here are the main Python scripts:
-PartA.2_Weinert_Cicala.py
-PartA.3_Weinert_Cicala.py
-PartB_Weinert_Cicala.py
-PartC_Weinert_Cicala.py
-PartD_Weinert_Cicala.py

📄 .env
Environment variables used for configuration (e.g., Neo4j credentials, paths).

📄 docker-compose.yml
Docker Compose file used to set up and orchestrate the environment with services such as Neo4j.

📄 PartA.1_Weinert_Cicala.png
First view of the graph (Part A.1), representing the initial structure.

📄 PartA.3_Weinert_Cicala.png
Updated graph view (Part A.3), showing additional entities and relationships.

📄 PartA.3_Weinert_Cicala_zoom.png
Zoomed-in version of the updated graph, focusing on the new elements introduced in Part A3 compared to the previous version.

📄 DOC_Weinert_Cicala.pdf
Report of the project
