import pandas as pd
import random
from collections import defaultdict
from rdflib import Graph, Namespace, RDF, Literal
from rdflib.namespace import XSD

# For statistics
class_counts = defaultdict(int)
property_counts = defaultdict(int)
used_classes = set()
used_properties = set()

# LIMITS CONFIGURATION (considering that we load all the 4G DBLP XML dataset)
MAX_AUTHORS = 90000     # Limit for authors
MAX_PAPERS = 90000     # Limit for papers  
MAX_CITATIONS = 50000  # Limit for citations
MAX_AUTHOR_PAPER = 90000  # Limit for author-paper relationships
MAX_KEYWORDS_PAPER = 100000  # Limit for keywords
MAX_REVIEW = 50000  # Limit for reviews
# Function to add triples to the graph and update statistics
def add_triple(s, p, o):
    g.add((s, p, o))
    if p == RDF.type:
        used_classes.add(o)
        class_counts[o] += 1
    else:
        used_properties.add(p)
        property_counts[p] += 1

# Setup
EX = Namespace("http://example.org/academic#")
g = Graph()
g.bind("ex", EX)

# AUTHORS
print("Processing AUTHORS...")
df = pd.read_csv("authors.csv", header=None, names=[":ID", "name", ":LABEL"], nrows=MAX_AUTHORS, skiprows=1)
print(f"Loaded {len(df)} authors (max: {MAX_AUTHORS})")

for _, row in df.iterrows():
    author_id = str(row[":ID"]).strip('"')
    name = str(row["name"]).strip('"')
    author_uri = EX[f"Author_{author_id}"]
    
    add_triple(author_uri, RDF.type, EX.Author)
    add_triple(author_uri, EX.personName, Literal(name, datatype=XSD.string))

# PAPERS
print("Processing PAPERS...")
df = pd.read_csv("papers.csv", header=None, names=[":ID", "key", "title", "doi", "abstract", ":LABEL"], nrows=MAX_PAPERS)
print(f"Loaded {len(df)} papers (max: {MAX_PAPERS})")

for _, row in df.iterrows():
    paper_id = str(row[":ID"]).strip('"')
    title = str(row["title"]).strip('"')
    doi = str(row["doi"]).strip('"')
    abstract = str(row["abstract"]).strip('"')

    paper_uri = EX[f"Paper_{paper_id}"]
    add_triple(paper_uri, RDF.type, EX.Paper)
    add_triple(paper_uri, EX.Title, Literal(title, datatype=XSD.string))
    add_triple(paper_uri, EX.DOI, Literal(doi, datatype=XSD.string))
    add_triple(paper_uri, EX.Abstract, Literal(abstract, datatype=XSD.string))

# PAPER-PAPER RELATIONSHIP (Citations)
print("Processing CITATIONS...")
df = pd.read_csv("cited_by.csv", header=None, names=[":START_ID", ":END_ID", ":TYPE"], nrows=MAX_CITATIONS)
print(f"Loaded {len(df)} citations")

for _, row in df.iterrows():
    citing = EX[f"Paper_{str(row[':START_ID']).strip()}"]
    cited = EX[f"Paper_{str(row[':END_ID']).strip()}"]
    add_triple(citing, EX.cites, cited)

# AUTHOR-PAPER RELATIONSHIP
print("Processing AUTHOR-PAPER relationships...")
df = pd.read_csv("wrote.csv", header=None, names=[":START_ID", ":END_ID", ":TYPE", "corresponding:boolean"], nrows=MAX_AUTHOR_PAPER)
print(f"Loaded {len(df)} author-paper relationships")

for _, row in df.iterrows():
    author = EX[f"Author_{str(row[':START_ID']).strip()}"]
    paper = EX[f"Paper_{str(row[':END_ID']).strip()}"]
    add_triple(author, EX.authorOf, paper)
    if str(row["corresponding:boolean"]).strip().lower() == "true":
        add_triple(author, EX.correspondingAuthorOf, paper)

# EVENTS
print("Processing EVENTS...")
df = pd.read_csv("events.csv", header=None, names=[":ID", "name", "event_type", ":LABEL"])
print(f"Loaded {len(df)} events")

for _, row in df.iterrows():
    eid = str(row[":ID"]).strip().strip('"')
    name = str(row["name"]).strip('"')
    etype = str(row["event_type"]).lower().strip()
    
    if etype not in ["conference", "workshop"]:
        continue

    event_uri = EX[f"Event_{eid}"]
    
    if etype == "conference":
        add_triple(event_uri, RDF.type, EX.Conference)
        add_triple(event_uri, EX.conferenceName, Literal(name, datatype=XSD.string))
    elif etype == "workshop":
        add_triple(event_uri, RDF.type, EX.Workshop)
        add_triple(event_uri, EX.workshopName, Literal(name, datatype=XSD.string))

# EDITIONS
print("Processing EDITIONS...")
df = pd.read_csv("editions.csv", header=None, names=[":ID", "title", "year", "city", ":LABEL"], skiprows=1)
print(f"Loaded {len(df)} editions")

for _, row in df.iterrows():
    eid = str(row[":ID"]).strip().strip('"')
    title = str(row["title"]).strip('"')
    year = str(row["year"]).strip('"')
    city = str(row["city"]).strip('"')

    if not city or pd.isna(city) or city.lower() == 'nan' or city.lower() == 'city':
        print(f"City missing for edition {eid}.")
        continue

    edition_uri = EX[f"Edition_{eid}"]
    city_uri = EX[f"City_{city.replace(' ', '_')}"]

    add_triple(edition_uri, RDF.type, EX.Edition)
    if year.isdigit():
        add_triple(edition_uri, EX.editionYear, Literal(int(year), datatype=XSD.gYear))
    add_triple(edition_uri, EX.heldInCity, city_uri)
    add_triple(city_uri, RDF.type, EX.City)
    add_triple(city_uri, EX.cityName, Literal(city, datatype=XSD.string))

# EDITION-EVENT RELATIONSHIP
print("Processing EDITION-EVENT relationships...")
df = pd.read_csv("has_edition.csv", header=None, names=[":START_ID", ":END_ID", ":TYPE"])
print(f"Loaded {len(df)} edition-event relationships")

for _, row in df.iterrows():
    event = EX[f"Event_{str(row[':START_ID']).strip()}"]
    edition = EX[f"Edition_{str(row[':END_ID']).strip()}"]
    add_triple(event, EX.hasEdition, edition)

# VOLUMES
print("Processing VOLUMES...")
df = pd.read_csv("volumes.csv", names=[":ID","year","volume_number", ":LABEL"], quotechar='"', skiprows=1)
print(f"Loaded {len(df)} volumes")

for _, row in df.iterrows():
    try:
        vid = str(row[":ID"]).strip().strip('"')
        year = int(str(row["year"]).strip().strip('"'))
        number = str(row["volume_number"]).strip().strip('"')

        volume_uri = EX[f"Volume_{vid}"]
        add_triple(volume_uri, RDF.type, EX.Volume)
        add_triple(volume_uri, EX.volumeYear, Literal(year, datatype=XSD.gYear))
        add_triple(volume_uri, EX.volumeNumber, Literal(number, datatype=XSD.string))
    except Exception as e:
        print(f"Error processing volume row {row}: {e}")

# JOURNALS
print("Processing JOURNALS...")
df = pd.read_csv("journals.csv", header=None, names=[":ID", "name", ":LABEL"])
print(f"Loaded {len(df)} journals")

for _, row in df.iterrows():
    jid = str(row[":ID"]).strip().strip('"')
    name = str(row["name"]).strip('"')

    journal_uri = EX[f"Journal_{jid}"]
    add_triple(journal_uri, RDF.type, EX.Journal)
    add_triple(journal_uri, EX.journalName, Literal(name, datatype=XSD.string))

# JOURNALS-VOLUME RELATIONSHIP
print("Processing JOURNAL-VOLUME relationships...")
df = pd.read_csv("has_volume.csv", header=None, names=[":START_ID", ":END_ID", ":TYPE"])
print(f"Loaded {len(df)} journal-volume relationships")

for _, row in df.iterrows():
    journal = EX[f"Journal_{str(row[':START_ID']).strip()}"]
    volume = EX[f"Volume_{str(row[':END_ID']).strip()}"]
    add_triple(journal, EX.hasVolume, volume)

# KEYWORDS
print("Processing KEYWORDS...")
df = pd.read_csv("keywords.csv", header=None, names=[":ID", "keyword", ":LABEL"], skiprows=1)
print(f"Loaded {len(df)} keywords")

for _, row in df.iterrows():
    kid = str(row[":ID"]).strip().strip('"')
    keyword = str(row["keyword"]).strip('"')

    kw_uri = EX[f"Keyword_{kid}"]
    add_triple(kw_uri, RDF.type, EX.Keyword)
    add_triple(kw_uri, EX.topic, Literal(keyword, datatype=XSD.string))

# KEYWORDS-PAPER RELATIONSHIP
print("Processing KEYWORD-PAPER relationships...")
df = pd.read_csv("kw_indexes.csv", header=None, names=[":START_ID", ":END_ID", ":TYPE"], nrows=MAX_KEYWORDS_PAPER)
print(f"Loaded {len(df)} keyword-paper relationships")

for _, row in df.iterrows():
    keyword = EX[f"Keyword_{str(row[':START_ID']).strip()}"]
    paper = EX[f"Paper_{str(row[':END_ID']).strip()}"]
    add_triple(paper, EX.hasTopic, keyword)

# PUBLICATION-PAPER RELATIONSHIP 
print("Processing PUBLICATION-PAPER relationships...")

# First, load publication IDs to distinguish volumes from editions
volume_ids = set()
edition_ids = set()

# Load volume IDs
print("Loading volume IDs...")
df_vol = pd.read_csv("volumes.csv", quotechar='"')
for _, row in df_vol.iterrows():
    vid = str(row[":ID"]).strip().strip('"')
    volume_ids.add(vid)

# Load edition IDs
print("Loading edition IDs...")
df_ed = pd.read_csv("editions.csv", header=None, names=[":ID", "title", "year", "city", ":LABEL"])
for _, row in df_ed.iterrows():
    eid = str(row[":ID"]).strip().strip('"')
    edition_ids.add(eid)

print(f"Loaded {len(volume_ids)} volume IDs and {len(edition_ids)} edition IDs")

# Process publication-paper relationships with limit
#Edition
start1 = 10
stop1 = 9000  
df1 = pd.read_csv(
    "has_paper.csv",
    names=[":START_ID", ":END_ID", ":TYPE"],
    skiprows=range(1, start1),
    nrows=stop1 - start1
)

# Volumes (from 4,200,001 )
start2 = 4200000  
stop2 = 4200000 + 11000   
df2 = pd.read_csv(
    "has_paper.csv",
    names=[":START_ID", ":END_ID", ":TYPE"],
    skiprows=range(1, start2),
    nrows=stop2 - start2
)

# combine the two DataFrames
df_combined = pd.concat([df1, df2])
print(f"Loaded {len(df)} has_paper relationships")

volume_papers = 0
edition_papers = 0
unknown_papers = 0

for _, row in df_combined.iterrows():
    pub_id = str(row[':START_ID']).strip().strip('"')
    paper_uri = EX[f"Paper_{str(row[':END_ID']).strip()}"]
    
    if pub_id in volume_ids:
        publication_uri = EX[f"Volume_{pub_id}"]
        add_triple(paper_uri, EX.publishedIn, publication_uri)
        volume_papers += 1
    elif pub_id in edition_ids:
        publication_uri = EX[f"Edition_{pub_id}"]
        add_triple(paper_uri, EX.publishedIn, publication_uri)
        edition_papers += 1
    else:
        #print(f"Warning: Publication ID {pub_id} not found in volumes or editions")
        unknown_papers += 1

print(f"Papers published in volumes: {volume_papers}")
print(f"Papers published in editions: {edition_papers}")
print(f"Papers with unknown publications: {unknown_papers}")

# REVIEWS
print("Processing REVIEWS...")
positive_comments = [
    "Well written paper.",
    "Excellent contribution.",
    "Very relevant and insightful.",
    "Clear methodology and results.",
    "Strong theoretical foundation.",
    "Innovative approach.",
    "Impressive data analysis.",
    "Well structured and easy to follow.",
]

negative_comments = [
    "Lacks clarity and rigor.",
    "Insufficient evidence.",
    "Results not convincing.",
    "Poorly structured and hard to follow.",
    "Weak theoretical basis.",
    "Methodology needs improvement.",
]

df = pd.read_csv("reviewed.csv", header=None,names=[":START_ID", ":END_ID", ":TYPE"], nrows=MAX_REVIEW)
print(f"Loaded {len(df)} reviews")

# Group reviews by paper
reviews_by_paper = defaultdict(list)
for _, row in df.iterrows():
    reviewer_id = str(row[":START_ID"]).strip().strip('"')
    paper_id = str(row[":END_ID"]).strip().strip('"')
    reviews_by_paper[paper_id].append(reviewer_id)

# Generate review triples
for paper_id, reviewers in reviews_by_paper.items():
    random.shuffle(reviewers)
    accepted_count = min(2, len(reviewers))
    decisions = ['accepted'] * accepted_count + ['rejected'] * (len(reviewers) - accepted_count)
    random.shuffle(decisions)

    for reviewer_id, decision in zip(reviewers, decisions):
        review_uri = EX[f"Review_{reviewer_id}_{paper_id}"]
        reviewer_uri = EX[f"Author_{reviewer_id}"]
        paper_uri = EX[f"Paper_{paper_id}"]

        add_triple(review_uri, RDF.type, EX.Review)
        add_triple(reviewer_uri, RDF.type, EX.Reviewer)
        add_triple(paper_uri, EX.hasReview, review_uri)
        add_triple(review_uri, EX.performedBy, reviewer_uri)
        add_triple(review_uri, EX.decision, Literal(decision, datatype=XSD.string))

        comment = random.choice(positive_comments if decision == "accepted" else negative_comments)
        add_triple(review_uri, EX.comment, Literal(comment, datatype=XSD.string))

# Serialization
print("Serializing graph...")
g.serialize("academic_abox.ttl", format="turtle")

# Statistics
print(f"\n=== FINAL STATISTICS ===")
print(f"Total triples: {len(g)}")
print(f"Number of distinct classes used: {len(used_classes)}")
print(f"Number of distinct properties used: {len(used_properties)}")
print(f"\nLimits applied:")
print(f"  Max authors: {MAX_AUTHORS}")
print(f"  Max papers: {MAX_PAPERS}")
print(f"  Max citations: {MAX_CITATIONS}")
print(f"  Max author-paper relationships: {MAX_AUTHOR_PAPER}")  
print(f"  Max keywords-paper relationships: {MAX_KEYWORDS_PAPER}")
print(f"  Max reviews: {MAX_REVIEW}")
print("\nInstances per class:")
for cls, count in class_counts.items():
    print(f"  {cls.split('#')[-1]}: {count}")
print("\nTriples per property:")
for prop, count in property_counts.items():
    print(f"  {prop.split('#')[-1]}: {count}")

print("\nABox creation completed successfully!")