from rdflib import Graph, Namespace, RDF, RDFS, XSD

# Namespaces & graph
EX  = Namespace("http://example.org/academic#")
g   = Graph()
g.bind("ex", EX)
g.bind("rdfs", RDFS)
g.bind("xsd", XSD)

# Classes
def add_classes(*iris):
    for iri in iris:
        g.add((iri, RDF.type, RDFS.Class))

add_classes(EX.Author, EX.Reviewer,
            EX.Paper, EX.Publication,  EX.Volume,
            EX.Event, EX.Conference, EX.Workshop, EX.Edition,
            EX.Journal, EX.Keyword, EX.Review, EX.City) #EX.Scientist, EX.Chair, EX.Editor,  EX.Person, EX.Affiliation

# 3. Class hierarchy
g.add((EX.Reviewer,  RDFS.subClassOf, EX.Author)) # g.add((EX.Reviewer,  RDFS.subClassOf, EX.Scientist))
#g.add((EX.Scientist, RDFS.subClassOf, EX.Author))

#g.add((EX.Author, RDFS.subClassOf, EX.Person))
#g.add((EX.Chair, RDFS.subClassOf, EX.Person))
#g.add((EX.Editor, RDFS.subClassOf, EX.Person))

g.add((EX.Conference,  RDFS.subClassOf, EX.Event))
g.add((EX.Workshop,  RDFS.subClassOf, EX.Event))
g.add((EX.Edition, RDFS.subClassOf, EX.Publication))
g.add((EX.Volume,      RDFS.subClassOf, EX.Publication))

# Properties
def add_objprop(prop, domain, range_):
    g.add((prop, RDF.type, RDF.Property))
    g.add((prop, RDFS.domain, domain))
    g.add((prop, RDFS.range,  range_))

add_objprop(EX.authorOf, EX.Author, EX.Paper)
#add_objprop(EX.writtenBy, EX.Paper, EX.Author)
add_objprop(EX.correspondingAuthorOf, EX.Author, EX.Paper)
add_objprop(EX.cites,    EX.Paper, EX.Paper)

add_objprop(EX.hasTopic, EX.Paper, EX.Keyword)
add_objprop(EX.publishedIn, EX.Paper, EX.Publication)  
add_objprop(EX.hasEdition, EX.Event, EX.Edition)

add_objprop(EX.heldInCity,   EX.Edition,    EX.City)


add_objprop(EX.hasVolume,    EX.Journal,    EX.Volume)

add_objprop(EX.hasReview, EX.Paper,   EX.Review)
add_objprop(EX.performedBy,  EX.Review,  EX.Reviewer)

#add_objprop(EX.assignedBy, EX.Review, EX.Chair)  
#add_objprop(EX.assignedBy, EX.Review, EX.Editor)   

#add_objprop(EX.affiliatedWith, EX.Author, EX.Affiliation)

# Datatype properties
def add_dtprop(prop, domain, range_):
    g.add((prop, RDF.type, RDF.Property))
    g.add((prop, RDFS.domain, domain))
    g.add((prop, RDFS.range,  range_))

add_dtprop(EX.personName, EX. Author,   XSD.string)

add_dtprop(EX.Title, EX.Paper,   XSD.string)
add_dtprop(EX.DOI, EX.Paper,   XSD.string)
add_dtprop(EX.Abstract,  EX.Paper,   XSD.string)

add_dtprop(EX.conferenceName, EX.Conference,   XSD.string)

add_dtprop(EX.workshopName, EX.Workshop,   XSD.string)

add_dtprop(EX.journalName, EX.Journal,   XSD.string)

#add_dtprop(EX.affiliationName, EX.Affiliation,   XSD.string)

add_dtprop(EX.editionYear,  EX.Edition, XSD.gYear)

add_dtprop(EX.volumeNumber, EX.Volume,  XSD.string)
add_dtprop(EX.volumeYear, EX.Volume,  XSD.gYear)

add_dtprop(EX.decision, EX.Review, XSD.string)
add_dtprop(EX.comment, EX.Review, XSD.string)

add_dtprop(EX.topic, EX.Keyword, XSD.string)

add_dtprop(EX.cityName, EX.City, XSD.string)
# 7. Serialize
g.serialize(destination="academic_tbox.ttl", format="turtle")
print("TBox stored to academic_tbox.ttl")
print("TBox contains", len(g), "triples")