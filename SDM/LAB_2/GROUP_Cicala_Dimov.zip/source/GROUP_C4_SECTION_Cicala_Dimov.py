import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, silhouette_score
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram, linkage
import pandas as pd
import seaborn as sns
import torch
import gc
import pykeen
import networkx as nx
import os
import time
import subprocess
import psutil

# Constants
MAX_AUTHORS = 10000  # Maximum number of authors to analyze

# Load model
model_name = "best_TransE_model"

model = torch.load(
	"./" + model_name + "/trained_model.pkl",
	map_location=torch.device('cpu'),
	weights_only=False
)

file_path = "./"+ model_name+'/training_triples/relation_to_id.tsv.gz'
df = pd.read_csv(file_path, sep='\t', compression='gzip', header=0)
relation_to_id = dict(zip(df.iloc[:, 1], df.iloc[:, 0]))
file_path = "./"+ model_name+'/training_triples/entity_to_id.tsv.gz'
df = pd.read_csv(file_path, sep='\t', compression='gzip', header=0)
entity_to_id = dict(zip(df.iloc[:, 1], df.iloc[:, 0]))

entity_embeddings = model.entity_representations[0]().detach().numpy()
relation_embeddings = model.relation_representations[0]().detach().numpy()

def extract_entity_types(entity_to_id, max_authors=MAX_AUTHORS):
    """Extract different entity types with memory limits"""
    entity_types = {
        'authors': [],
        'papers': [],
        'journals': [],
        'volumes': [],
        'editions': [],
        'reviews': [],
        'events': []
    }
    
    author_count = 0
    for entity, idx in entity_to_id.items():
        entity_lower = entity.lower()
        if 'author' in entity_lower and author_count < max_authors:
            entity_types['authors'].append((entity, idx))
            author_count += 1
        elif 'paper' in entity_lower:
            entity_types['papers'].append((entity, idx))
        elif 'journal' in entity_lower:
            entity_types['journals'].append((entity, idx))
        elif 'volume' in entity_lower:
            entity_types['volumes'].append((entity, idx))
        elif 'edition' in entity_lower:
            entity_types['editions'].append((entity, idx))
        elif 'review' in entity_lower:
            entity_types['reviews'].append((entity, idx))
        elif 'event' in entity_lower:
            entity_types['events'].append((entity, idx))
    
    return entity_types

def find_optimal_clusters(author_embeddings, max_clusters=30):
    """
    Find the optimal number of clusters using silhouette score
    """
    # Calculate linkage matrix
    Z = linkage(author_embeddings, method='ward')
    
    # Plot dendrogram
    plt.figure(figsize=(15, 7))
    dendrogram(Z, truncate_mode='level', p=5)
    plt.title('Hierarchical Clustering Dendrogram')
    plt.xlabel('Sample Index')
    plt.ylabel('Distance')
    plt.savefig('dendrogram.png')
    plt.close()
    
    # Try different numbers of clusters
    silhouette_scores = []
    n_clusters_range = range(2, max_clusters + 1)
    
    for n_clusters in n_clusters_range:
        # Try both K-means and Agglomerative Clustering
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=20)
        agg_cluster = AgglomerativeClustering(n_clusters=n_clusters)
        
        kmeans_labels = kmeans.fit_predict(author_embeddings)
        agg_labels = agg_cluster.fit_predict(author_embeddings)
        
        # Calculate metrics for both methods
        kmeans_silhouette = silhouette_score(author_embeddings, kmeans_labels)
        agg_silhouette = silhouette_score(author_embeddings, agg_labels)
        
        # Use the better performing method
        silhouette_scores.append(max(kmeans_silhouette, agg_silhouette))
    
    # Plot the results
    plt.figure(figsize=(10, 5))
    plt.plot(n_clusters_range, silhouette_scores, 'bo-')
    plt.xlabel('Number of Clusters')
    plt.ylabel('Silhouette Score')
    plt.title('Silhouette Score vs Number of Clusters')
    plt.savefig('cluster_optimization.png')
    plt.close()
    
    # Hardcode optimal number of clusters to 5
    optimal_n_clusters = 5
    
    return optimal_n_clusters, silhouette_scores

def perform_clustering_analysis(entity_embeddings, entity_types, n_clusters=5):
    """
    Perform comprehensive clustering analysis on author embeddings
    """
    # Extract author embeddings
    author_indices = [idx for _, idx in entity_types['authors']]
    author_embeddings = entity_embeddings[author_indices]
    
    print(f"\nProcessing {len(author_indices)} authors...")
    print(f"Original embedding shape: {author_embeddings.shape}")
    
    # Remove outliers using IQR method
    Q1 = np.percentile(author_embeddings, 25, axis=0)
    Q3 = np.percentile(author_embeddings, 75, axis=0)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    mask = np.all((author_embeddings >= lower_bound) & (author_embeddings <= upper_bound), axis=1)
    author_embeddings_clean = author_embeddings[mask]
    print(f"Removed {len(author_embeddings) - len(author_embeddings_clean)} outliers")
    
    # Standardize the embeddings
    scaler = StandardScaler()
    author_embeddings_scaled = scaler.fit_transform(author_embeddings_clean)
    print(f"Standardized embedding shape: {author_embeddings_scaled.shape}")
    
    # Find optimal number of clusters
    print("\nFinding optimal number of clusters...")
    optimal_n_clusters, silhouette_scores = find_optimal_clusters(author_embeddings_scaled)
    print(f"Optimal number of clusters: {optimal_n_clusters}")
    
    # Use the optimal number of clusters
    n_clusters = optimal_n_clusters
    
    # Try both K-means and Agglomerative Clustering
    kmeans = KMeans(n_clusters=n_clusters, n_init=30, max_iter=1000, random_state=42)
    kmeans_labels = kmeans.fit_predict(author_embeddings_scaled)
    kmeans_score = silhouette_score(author_embeddings_scaled, kmeans_labels)
    
    agg_cluster = AgglomerativeClustering(n_clusters=n_clusters)
    agg_labels = agg_cluster.fit_predict(author_embeddings_scaled)
    agg_score = silhouette_score(author_embeddings_scaled, agg_labels)
    
    # Use the better performing method
    if kmeans_score > agg_score:
        print("\nUsing K-means clustering (better silhouette score)")
        best_labels = kmeans_labels
        best_score = kmeans_score
        best_method = "K-means"
    else:
        print("\nUsing Agglomerative clustering (better silhouette score)")
        best_labels = agg_labels
        best_score = agg_score
        best_method = "Agglomerative"
    
    print(f"Best silhouette score: {best_score:.3f}")
    
    # Perform t-SNE for visualization
    print("\nPerforming t-SNE dimensionality reduction...")
    tsne = TSNE(n_components=2, random_state=42, perplexity=min(30, len(author_embeddings_scaled)-1))
    author_embeddings_tsne = tsne.fit_transform(author_embeddings_scaled)
    
    # Create visualizations
    print("\nGenerating visualizations...")
    plt.figure(figsize=(15, 5))
    
    # Plot t-SNE visualization with best clusters
    plt.subplot(1, 2, 1)
    scatter = plt.scatter(author_embeddings_tsne[:, 0], author_embeddings_tsne[:, 1], 
                         c=best_labels, cmap='viridis')
    plt.title(f't-SNE Visualization with {best_method} Clusters')
    plt.colorbar(scatter)
    
    # Plot cluster size distribution
    plt.subplot(1, 2, 2)
    cluster_sizes = np.bincount(best_labels)
    plt.bar(range(len(cluster_sizes)), cluster_sizes)
    plt.title(f'{best_method} Cluster Size Distribution')
    plt.xlabel('Cluster')
    plt.ylabel('Number of Authors')
    
    plt.tight_layout()
    plt.savefig('author_clustering_analysis.png')
    plt.close()
    
    print("\nAnalysis complete! Results saved to 'author_clustering_analysis.png'")
    
    # Create detailed analysis report
    analysis_report = {
        'clustering_metrics': {
            'silhouette_score': best_score,
            'cluster_sizes': cluster_sizes.tolist(),
            'method': best_method
        },
        'total_authors': len(author_embeddings_clean),
        'optimal_clusters': optimal_n_clusters
    }
    
    return analysis_report, best_labels, best_labels, author_embeddings_clean

def analyze_cluster_characteristics(entity_embeddings, entity_types, cluster_labels, author_embeddings_clean):
    """
    Analyze the characteristics of each cluster
    """
    # Calculate cluster centroids
    unique_clusters = np.unique(cluster_labels)
    cluster_centroids = []
    
    for cluster in unique_clusters:
        if cluster != -1:  # Skip noise points from DBSCAN
            cluster_mask = cluster_labels == cluster
            centroid = np.mean(author_embeddings_clean[cluster_mask], axis=0)
            cluster_centroids.append(centroid)
    
    # Calculate pairwise cosine similarities between centroids
    centroid_similarities = cosine_similarity(cluster_centroids)
    
    # Visualize cluster similarities
    plt.figure(figsize=(10, 8))
    sns.heatmap(centroid_similarities, annot=True, cmap='viridis')
    plt.title('Cluster Centroid Similarities')
    plt.savefig('cluster_similarities.png')
    plt.close()
    
    return centroid_similarities

# Main execution
if __name__ == "__main__":
    # Extract entity types
    entity_types = extract_entity_types(entity_to_id)
    
    # Perform clustering analysis
    analysis_report, kmeans_labels, dbscan_labels, author_embeddings_clean = perform_clustering_analysis(
        entity_embeddings, entity_types, n_clusters=5
    )
    
    # Analyze cluster characteristics
    centroid_similarities = analyze_cluster_characteristics(
        entity_embeddings, entity_types, kmeans_labels, author_embeddings_clean
    )
    
    # Print analysis results
    print("\nClustering Analysis Results:")
    print(f"Total number of authors analyzed: {analysis_report['total_authors']}")
    print("\nClustering Metrics:")
    print(f"Silhouette Score: {analysis_report['clustering_metrics']['silhouette_score']:.3f}")
    print("\nCluster Sizes:")
    for i, size in enumerate(analysis_report['clustering_metrics']['cluster_sizes']):
        print(f"Cluster {i}: {size} authors")
