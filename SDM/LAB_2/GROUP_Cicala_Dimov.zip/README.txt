This repository contains all the necessary files and resources for reproducing the work. Below is a description of the folder and file structure:

📁 data/
Directory for CSVs (from the previous lab) if you want to look at them (Remember they have a huge size)
You can download them using the link: https://1drv.ms/u/s!AsezANZLUWP9kPgZz7lbh1akCku2wg?e=dRQLPy 

📁 result/
Contains all the output file requested during the sections of the assignment.
B1_TBOX_Cicala_Dimov.ttl
B2_ABOX_Cicala_Dimov.ttl
B3_query1_result_Cicala_Dimov.csv
B3_query2_result_Cicala_Dimov.csv
C1_query_result_Cicala_Dimov.tsv


📁 images/
All the images reported in the report. 
B1_TBOX_Cicala_Dimov.jpg
B1_TBOX_WEB_Cicala_Dimov.tex
C2_4_Cicala_Dimov.png
C2_5_Cicala_Dimov.png
C4_author_clustering_analysis_Cicala_Dimov.png
C4_cluster_optimization_Cicala_Dimov.png
C4_cluster_similarities_Cicala_Dimov.png
C4_dendrogram_Cicala_Dimov.png

📁 source/
Contains the source code (Python scripts and notebooks) used to build and analyze the graph.
-GROUP_B1_SECTION_Cicala_Dimov.py
-GROUP_B2_SECTION_Cicala_Dimov.py
-GROUP_C2_SECTION_Cicala_Dimov.ipynb
-GROUP_C3_SECTION_Cicala_Dimov.ipynb
-GROUP_C4_SECTION_Cicala_Dimov.py

📄 GROUP_Cicala_Dimov.pdf
Report of the project
