In this zipped folder, you will find: 
(1) three Python scripts that can be executed from the terminal as shown in the PDF 
(2) the 'Part1_ZipfsLaw' folder, which contains both sorted and unsorted files with word-occurrence lists for each index (novels-news-abstracts) 
(3) the 'Grouped_novels' folder, which contains the 8 groups of novels used for the second part (Heaps' law)
(4) the 'Part2_Heapslaw' folder, which contains both sorted and unsorted files with word-occurrence lists for each index (referring to the 8 groups of novels)
(5) the PDF with theoretical explanations and practical details of the work carried out
(6) the 'Plots_ZipfsLaw' folder containing the rank-frequency plots (both log-log and standard) that follow Zipf's law