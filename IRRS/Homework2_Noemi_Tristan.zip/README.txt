In this folder you can find:
- "Token" repository where there are the output files (on novels) that helped us to find the most aggrassive token among the available ones (depending on the number of the words)
- "Flags" repository where there are the output files (on news) that helped us to find the most common word in english Language
-"TFDF output" repository where you can find the similarities computed between different pairs of files (from the same or different topics) of the various available corpus (novels, news, abstracts), output of the TFIDFViewer.py script
- Python scripts that were provided by the assigment
-TFIDFViewer.py script (completed) to give in output the ones containing in the "TFDF output" repository
-IRRS_Lab2_Noemi_Tristan.pdf, the report in which is explained and discussed what and how we have obtained the previous elements