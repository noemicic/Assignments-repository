from mrjob.job import MRJob
from mrjob.step import MRStep
from collections import defaultdict

class MRKmeansStep(MRJob):
    prototypes = {}

    def jaccard(self, prot, doc):
        """
        Compute the Jaccard similarity between a prototype and a document.
        prot should be a list of pairs (word, probability).
        doc should be a list of words.
        
        prot_words = {word for word, _ in prot}
        doc_words = set(doc)

        intersection = len(prot_words & doc_words)
        union = len(prot_words | doc_words)
        return intersection / union if union > 0 else 0.0
        """
        prot_words = {word for word, _ in prot}
        doc_words = set(doc)

        intersection = prot_words & doc_words
        union = prot_words | doc_words

        # Pondera la similarità considerando la probabilità dei termini
        intersection_prob = sum(prob for word, prob in prot if word in intersection)
        union_prob = sum(prob for word, prob in prot) + len(doc_words)  # Probabilità di tutti i termini

        return intersection_prob / union_prob if union_prob > 0 else 0.0

    def configure_args(self):
        """
        Additional configuration flag to get the prototypes file.
        """
        super(MRKmeansStep, self).configure_args()
        self.add_file_arg('--prot')

    def load_data(self):
        """
        Load the current cluster prototypes.
        """
        with open(self.options.prot, 'r') as f:
            for line in f:
                cluster, words = line.split(':')
                cp = []
                for word in words.split():
                    token, prob = word.split('+')
                    cp.append((token, float(prob)))
                self.prototypes[cluster] = cp

    def assign_prototype(self, _, line):
        """
        Mapper: Assigns each document to the closest prototype.
        """
        # Each line is in the format: docid:word1 word2 ... wordn
        doc_id, words = line.split(':')
        doc_words = words.split()

        # Find the closest prototype by Jaccard similarity
        best_similarity = -1
        best_cluster = None
        for cluster, prototype in self.prototypes.items():
            similarity = self.jaccard(prototype, doc_words)
            if similarity > best_similarity:
                best_similarity = similarity
                best_cluster = cluster

        # Emit the cluster ID and the document's words
        yield best_cluster, doc_words

    def aggregate_prototype(self, cluster, values):
        """
        Reducer: Recalculate the cluster prototypes.
        """
        word_freq = defaultdict(float)
        doc_count = 0

        # Aggregate word frequencies for the cluster
        for doc_words in values:
            doc_count += 1
            for word in doc_words:
                word_freq[word] += 1

        # Compute the new prototype by normalizing frequencies
        new_prototype = []
        for word, freq in sorted(word_freq.items()):  # Sorting ensures alphabetical order
            new_prototype.append(f"{word}+{freq / doc_count}")

        # Emit the new cluster prototype
        yield cluster, " ".join(new_prototype)

    def steps(self):
        return [MRStep(mapper_init=self.load_data, 
                       mapper=self.assign_prototype,
                       reducer=self.aggregate_prototype)]

if __name__ == '__main__':
    MRKmeansStep.run()
