In this zip repository you'll find:
- the report in which there are explainations and methods evaluated for the goals of this lab
- all the "modificated"/completed Python scripts that you can run to ensure the results that we've obtained
- 4 zip repositories, one for each configuration used in the sperimentation (details in the report), in which there are all the output files obtained once the scripts are runned