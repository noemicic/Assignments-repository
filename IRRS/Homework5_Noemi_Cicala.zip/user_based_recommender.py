import pandas as pd
import numpy as np

import similarity as sim
import naive_recommender as nav
import utils as ut


def generate_m(movies_idx, users, ratings):
    # Complete the datastructure for rating matrix 
    m = {}
    for _, entry in ratings.iterrows():
        user_id = int(entry["userId"])
        movie_id = int(entry["movieId"])
        rating = entry["rating"]

        if user_id not in m:
            m[user_id] = {"ratings": {}, "mean_rating": 0}
        m[user_id]["ratings"][movie_id] = rating

    for user_id in m:
        m[user_id]["mean_rating"] = np.mean(list(m[user_id]["ratings"].values()))
        
    return m



def user_based_recommender(target_user_idx, matrix, movies_idx):
    target_user = matrix[target_user_idx]["ratings"]
    target_mean = matrix[target_user_idx]["mean_rating"]
    recommendations = []
    
    # Compute the similarity between  the target user and each other user in the matrix. 
    # We recomend to store the results in a dataframe (userId and Similarity)
    similarities = []
    for user in matrix:
        if user != target_user_idx:
            similarity= sim.compute_similarity(target_user, matrix[user]["ratings"])
            similarities.append((user, similarity))
    topK = 100
    U = pd.DataFrame(similarities, columns=["userId", "Similarity"]).sort_values(by="Similarity", ascending=False)
    U = U.head(topK)

    # Determine the unseen movies by the target user. Those films are identified 
    # since don't have any rating. 
    watched_movies = set(target_user.keys())
    not_watched = {movie for movie in movies_idx if movie not in watched_movies}
    
    # Generate recommendations for unrated movies based on user similarity and ratings.
    for _, row in U.iterrows():
        user = row["userId"]
        similarity = row["Similarity"]
        user_mean = matrix[user]["mean_rating"]
        user_ratings = matrix[user]["ratings"]
        for movie, rating in user_ratings.items():
            if movie in not_watched:
                numerator = similarity * (rating - user_mean)
                denominator = abs(similarity)
                if denominator > 0:
                    predicted_rating = target_mean + numerator / denominator
                    recommendations.append((movie, predicted_rating))
                    not_watched.remove(movie)
    recommendations.sort(key=lambda x: x[1], reverse=True)
    return recommendations



if __name__ == "__main__":
    
    # Load the dataset
    path_to_ml_latest_small = 'ml-latest-small/'
    dataset = ut.load_dataset_from_source(path_to_ml_latest_small)

    # Ratings data
    val_movies = 5
    ratings_train, ratings_val = ut.split_users(dataset["ratings.csv"], val_movies)
    
    # Create matrix between user and movies 
    movies_idx = dataset["movies.csv"]["movieId"].values
    users_idy = list(set(ratings_train["userId"].values))
    m = generate_m(movies_idx, users_idy, ratings_train)

    # user-to-user similarity
    target_user_idx = 123
    recommendations = user_based_recommender(target_user_idx, m, movies_idx)
    
    # The following code print the top 5 recommended films to the user
    for recomendation in recommendations[:5]:
        rec_movie = dataset["movies.csv"][dataset["movies.csv"]["movieId"]  == recomendation[0]]
        print (" Recomendation: Movie: {} (Genre: {})".format(rec_movie["title"].values[0], rec_movie["genres"].values[0]))

    # Validation
    matrixmpa_genres = ut.matrix_genres(dataset["movies.csv"])








