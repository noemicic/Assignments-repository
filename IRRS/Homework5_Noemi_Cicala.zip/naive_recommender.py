import pandas as pd 
import utils as ut

def naive_recommender(ratings: object, movies:object, k: int = 10) -> list: 
    # Provide the code for the naive recommender here. This function should return 
    # the list of the top most viewed films according to the ranking (sorted in descending order).
    # Consider using the utility functions from the pandas library.
    movie_rating_counts = ratings.groupby('movieId')['rating'].count()
    movie_rating_sums = ratings.groupby('movieId')['rating'].sum()
    movie_rating_averages = movie_rating_sums / movie_rating_counts
    movie_rating_averages = movie_rating_averages.reset_index().merge(movies[['movieId', 'title']], on='movieId')
    top_rated_movies = movie_rating_averages.sort_values(by='rating', ascending=False).head(k)
    #print(top_rated_movies)
    return top_rated_movies['title'].tolist()

if __name__ == "__main__":    
    path_to_ml_latest_small = 'ml-latest-small/'
    dataset = ut.load_dataset_from_source(path_to_ml_latest_small)
    
    ratings, movies = dataset["ratings.csv"], dataset["movies.csv"]
    print("The top 10 most viewed films according to the ranking are:")
    l=naive_recommender(ratings, movies)
    for i in l:
        print(i)

