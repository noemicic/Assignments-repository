import numpy as np

def compute_similarity(vector1: dict, vector2: dict):
    # Implement the actual computation of similarity between vector1 and vector2.
    # The current implementation returns a placeholder value of 1. Update this function 
    # to perform the appropriate similarity calculation and return the result.
    
    common_items = set(vector1.keys()) & set(vector2.keys())
    if not common_items:
        return 0  

    mean_vector1 = np.mean([vector1[item] for item in common_items])
    mean_vector2 = np.mean([vector2[item] for item in common_items])

    numerator = sum((vector1[item] - mean_vector1) * (vector2[item] - mean_vector2) for item in common_items)
    denominator_v1 = sum((vector1[item] - mean_vector1) ** 2 for item in common_items)
    denominator_v2 = sum((vector2[item] - mean_vector2) ** 2 for item in common_items)

    denominator = np.sqrt(denominator_v1) * np.sqrt(denominator_v2)
    if denominator == 0:
        return 0
    
    similarity = numerator / denominator
    return similarity

    

if __name__ == "__main__":
    v1 = {1: 4, 2: 5}
    v2 = {3: 3, 4: 2}
    assert compute_similarity(v1, v2) == 0
    
    v3 = {1: 5, 2: 4, 3: 3}
    v4 = {1: 10, 2: 8, 3: 6}  # Scaled by 2
    assert round(compute_similarity(v3, v4)) == 1 
    
    v5 = {1: 1, 2: 2, 3: 3}
    v6 = {1: 3, 2: 2, 3: 1}
    assert round(compute_similarity(v5, v6)) == -1 




    
    